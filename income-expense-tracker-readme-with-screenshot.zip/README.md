# 💰 Income & Expense Tracker

## 📌 About the Project

The Income & Expense Tracker is a simple web-based application developed
using HTML, CSS, and JavaScript. It helps users manage daily income and
expenses, calculate total income and expenses, and view their remaining
balance.

Users can add and delete transactions. The summary updates
automatically, and transaction data is saved in the browser using
LocalStorage.

## 🖥️ Home Page Screenshot

![Income & Expense Tracker Home Page](screenshots/homepage.png)

## ✨ Features

-   Add income and expense transactions
-   Calculate total income
-   Calculate total expenses
-   Display remaining balance
-   View transaction history
-   Delete transactions
-   Form validation
-   Save transactions using LocalStorage
-   Responsive design

## 🛠️ Technologies Used

-   **HTML5** -- Page structure and form
-   **CSS3** -- Styling and responsive layout
-   **JavaScript** -- DOM manipulation, events, and calculations
-   **LocalStorage** -- Save transaction data in the browser

## 📂 Project Structure

``` text
income-expense-tracker/
├── index.html
├── style.css
├── script.js
├── README.md
└── screenshots/
    └── homepage.png
```

## 🚀 How to Run

1.  Clone or download this repository.
2.  Open the project folder in VS Code.
3.  Open `index.html` in your browser, or run it with Live Server.
4.  Add income and expense transactions to use the tracker.

## 📊 Balance Calculation

**Remaining Balance = Total Income − Total Expenses**

## 🎯 Project Objective

The objective of this beginner-level college project is to practice
HTML, CSS, and JavaScript by building a simple tool for tracking daily
money activities.

## 🤖 AI Assistance

AI tools were used for ideas, explanations, and debugging assistance.
The code was reviewed and practiced to understand how the project works.

## 🔮 Future Improvements

-   Category-wise filtering
-   Dark mode
-   CSV export
-   Expense charts

------------------------------------------------------------------------

**Project Type:** College Assignment \| **Level:** Beginner \| **Mode:**
Individual
